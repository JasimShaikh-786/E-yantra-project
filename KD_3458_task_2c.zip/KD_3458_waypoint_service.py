#!/usr/bin/env python3

import os
import json
import csv
import math
import itertools
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from geometry_msgs.msg import Pose
from sensor_msgs.msg import Image
from waypoint_navigation.srv import GetWaypoints
from ament_index_python.packages import get_package_share_directory

try:
    from cv_bridge import CvBridge
except ImportError:
    CvBridge = None

import cv2
import numpy as np

# Built-in arena grid intersection coordinates (fallback if CSV is missing)
FALLBACK_GRID_COORDINATES = {
    'A1': {'x': 6.1131, 'y': 6.1131}, 'B1': {'x': 4.9049, 'y': 6.1306}, 'C1': {'x': 3.6785, 'y': 6.1265}, 'D1': {'x': 2.4153, 'y': 6.025},
    'E1': {'x': 1.2113, 'y': 6.0221}, 'F1': {'x': 0.0068, 'y': 6.0941}, 'G1': {'x': -1.1982, 'y': 6.0255}, 'H1': {'x': -2.4025, 'y': 6.0271},
    'I1': {'x': -3.6743, 'y': 6.1415}, 'J1': {'x': -4.8826, 'y': 6.1194}, 'K1': {'x': -6.096, 'y': 6.1096}, 'A2': {'x': 6.1239, 'y': 4.8995},
    'B2': {'x': 4.88, 'y': 4.88}, 'C2': {'x': 3.6914, 'y': 4.9202}, 'D2': {'x': 2.4376, 'y': 4.8662}, 'E2': {'x': 1.2032, 'y': 4.7897},
    'F2': {'x': 0.0067, 'y': 4.7898}, 'G2': {'x': -1.1913, 'y': 4.795}, 'H2': {'x': -2.4241, 'y': 4.8663}, 'I2': {'x': -3.6835, 'y': 4.9279},
    'J2': {'x': -4.8661, 'y': 4.8796}, 'K2': {'x': -6.11, 'y': 4.8996}, 'A3': {'x': 6.126, 'y': 3.6781}, 'B3': {'x': 4.9186, 'y': 3.6902},
    'C3': {'x': 3.7042, 'y': 3.7042}, 'D3': {'x': 2.4595, 'y': 3.6857}, 'E3': {'x': 1.2098, 'y': 3.6139}, 'F3': {'x': 0.0066, 'y': 3.5752},
    'G3': {'x': -1.197, 'y': 3.6157}, 'H3': {'x': -2.4447, 'y': 3.6835}, 'I3': {'x': -3.687, 'y': 3.7007}, 'J3': {'x': -4.9155, 'y': 3.6987},
    'K3': {'x': -6.1124, 'y': 3.6782}, 'A4': {'x': 6.0201, 'y': 2.4134}, 'B4': {'x': 4.865, 'y': 2.437}, 'C4': {'x': 3.6843, 'y': 2.4588},
    'D4': {'x': 2.4454, 'y': 2.4454}, 'E4': {'x': 1.222, 'y': 2.4388}, 'F4': {'x': 0.0067, 'y': 2.3998}, 'G4': {'x': -1.201, 'y': 2.422},
    'H4': {'x': -2.4323, 'y': 2.4459}, 'I4': {'x': -3.6699, 'y': 2.458}, 'J4': {'x': -4.8559, 'y': 2.4392}, 'K4': {'x': -6.0101, 'y': 2.4148},
    'A5': {'x': 6.001, 'y': 1.2067}, 'B5': {'x': 4.7948, 'y': 1.2046}, 'C5': {'x': 3.6154, 'y': 1.2102}, 'D5': {'x': 2.4396, 'y': 1.2226},
    'E5': {'x': 1.1989, 'y': 1.1992}, 'F5': {'x': 0.0067, 'y': 1.2142}, 'G5': {'x': -1.1865, 'y': 1.2001}, 'H5': {'x': -2.4256, 'y': 1.2222},
    'I5': {'x': -3.5968, 'y': 1.2085}, 'J5': {'x': -4.8074, 'y': 1.2106}, 'K5': {'x': -5.9959, 'y': 1.2084}, 'A6': {'x': 6.0404, 'y': 0.0067},
    'B6': {'x': 4.7881, 'y': 0.0067}, 'C6': {'x': 3.5627, 'y': 0.0066}, 'D6': {'x': 2.3995, 'y': 0.0067}, 'E6': {'x': 1.2148, 'y': 0.0067},
    'F6': {'x': 0.0068, 'y': 0.0068}, 'G6': {'x': -1.1955, 'y': 0.0067}, 'H6': {'x': -2.3868, 'y': 0.0067}, 'I6': {'x': -3.5459, 'y': 0.0066},
    'J6': {'x': -4.776, 'y': 0.0067}, 'K6': {'x': -6.0264, 'y': 0.0067}, 'A7': {'x': 6.0239, 'y': -1.1979}, 'B7': {'x': 4.79, 'y': -1.19},
    'C7': {'x': 3.6105, 'y': -1.1951}, 'D7': {'x': 2.4365, 'y': -1.2074}, 'E7': {'x': 1.1982, 'y': -1.1852}, 'F7': {'x': 0.0067, 'y': -1.2005},
    'G7': {'x': -1.1862, 'y': -1.1859}, 'H7': {'x': -2.4221, 'y': -1.2071}, 'I7': {'x': -3.5994, 'y': -1.1959}, 'J7': {'x': -4.7958, 'y': -1.1943},
    'K7': {'x': -6.0118, 'y': -1.1982}, 'A8': {'x': 6.0348, 'y': -2.4055}, 'B8': {'x': 4.8663, 'y': -2.4241}, 'C8': {'x': 3.6845, 'y': -2.4453},
    'D8': {'x': 2.4467, 'y': -2.4331}, 'E8': {'x': 1.2227, 'y': -2.4266}, 'F8': {'x': 0.0067, 'y': -2.3863}, 'G8': {'x': -1.2004, 'y': -2.4073},
    'H8': {'x': -2.4297, 'y': -2.4297}, 'I8': {'x': -3.6729, 'y': -2.4467}, 'J8': {'x': -4.855, 'y': -2.4252}, 'K8': {'x': -6.011, 'y': -2.4015},
    'A9': {'x': 6.1051, 'y': -3.6516}, 'B9': {'x': 4.9322, 'y': -3.6867}, 'C9': {'x': 3.7015, 'y': -3.6878}, 'D9': {'x': 2.4583, 'y': -3.6703},
    'E9': {'x': 1.2109, 'y': -3.6036}, 'F9': {'x': 0.0066, 'y': -3.5459}, 'G9': {'x': -1.197, 'y': -3.6026}, 'H9': {'x': -2.4472, 'y': -3.6737},
    'I9': {'x': -3.6853, 'y': -3.6853}, 'J9': {'x': -4.9174, 'y': -3.6862}, 'K9': {'x': -6.0899, 'y': -3.6506}, 'A10': {'x': 6.1247, 'y': -4.8866},
    'B10': {'x': 4.881, 'y': -4.8674}, 'C10': {'x': 3.6923, 'y': -4.9076}, 'D10': {'x': 2.4377, 'y': -4.853}, 'E10': {'x': 1.204, 'y': -4.7795},
    'F10': {'x': 0.0067, 'y': -4.775}, 'G10': {'x': -1.1908, 'y': -4.7798}, 'H10': {'x': -2.4194, 'y': -4.8433}, 'I10': {'x': -3.6834, 'y': -4.914},
    'J10': {'x': -4.8643, 'y': -4.8643}, 'K10': {'x': -6.1201, 'y': -4.894}, 'A11': {'x': 6.1097, 'y': -6.0961}, 'B11': {'x': 4.8986, 'y': -6.1088},
    'C11': {'x': 3.6792, 'y': -6.114}, 'D11': {'x': 2.415, 'y': -6.0108}, 'E11': {'x': 1.2085, 'y': -5.997}, 'F11': {'x': 0.0068, 'y': -6.085},
    'G11': {'x': -1.1973, 'y': -6.0073}, 'H11': {'x': -2.4056, 'y': -6.0206}, 'I11': {'x': -3.6603, 'y': -6.1052}, 'J11': {'x': -4.896, 'y': -6.1226},
    'K11': {'x': -6.1156, 'y': -6.1156}
}


def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # top-left
    rect[2] = pts[np.argmax(s)]  # bottom-right

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  # top-right
    rect[3] = pts[np.argmax(diff)]  # bottom-left
    return rect


def get_intersection_name(cx, cy):
    # Each grid cell in 900x900 warped image is 75 pixels (900 / 12)
    col_idx = int(round(cx / 75.0)) - 1
    row_idx = int(round(cy / 75.0)) - 1

    col_idx = max(0, min(10, col_idx))
    row_idx = max(0, min(10, row_idx))

    col_letter = chr(65 + col_idx)
    row_number = row_idx + 1
    return f"{col_letter}{row_number}"


class WayPoints(Node):

    def __init__(self):
        super().__init__('waypoints_service')

        self.waypoints = []
        self.marker_ids = []
        self.route_ready = False
        self.grid_coords = self.load_grid_coordinates()

        if CvBridge is not None:
            self.bridge = CvBridge()
        else:
            self.bridge = None

        # Subscribe to /image_raw with reliable, transient local QoS profile
        qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL
        )
        self.image_sub = self.create_subscription(
            Image,
            '/image_raw',
            self.image_callback,
            qos
        )
        self.get_logger().info('Subscribed to /image_raw (RELIABLE, TRANSIENT_LOCAL). Waiting for arena frame...')

        # Service server for GetWaypoints
        self.srv = self.create_service(GetWaypoints, 'waypoints', self.waypoint_callback)
        self.get_logger().info('Waypoint service ready. Awaiting requests...')

    def load_grid_coordinates(self):
        # Look for grid coordinates in standard locations (including ~ expansion)
        candidate_paths = [
            os.path.expanduser('~/pico_ws/src/swift_pico/scripts/grid_whycode_coordinates.csv'),
            os.path.expanduser('~/pico_ws/src/swift_pico/src/grid_whycode_coordinates.json'),
            os.path.join(os.path.dirname(__file__), 'grid_whycode_coordinates.csv'),
            os.path.join(os.path.dirname(__file__), 'grid_whycode_coordinates.json'),
            '/home/tanishq/pico_ws/src/swift_pico/scripts/grid_whycode_coordinates.csv',
            '/home/tanishq/pico_ws/src/swift_pico/src/grid_whycode_coordinates.json',
        ]
        try:
            share_dir = get_package_share_directory('swift_pico')
            candidate_paths.insert(0, os.path.join(share_dir, 'scripts', 'grid_whycode_coordinates.csv'))
            candidate_paths.insert(1, os.path.join(share_dir, 'scripts', 'grid_whycode_coordinates.json'))
        except Exception:
            pass

        grid = {}
        for p in candidate_paths:
            if os.path.exists(p):
                try:
                    if p.endswith('.json'):
                        with open(p, 'r') as f:
                            grid = json.load(f)
                            self.get_logger().info(f'Loaded grid coordinates from {p}')
                            return grid
                    elif p.endswith('.csv'):
                        with open(p, 'r') as f:
                            reader = csv.DictReader(f)
                            for row in reader:
                                grid[row['intersection']] = {'x': float(row['x']), 'y': float(row['y'])}
                            self.get_logger().info(f'Loaded grid coordinates from {p}')
                            return grid
                except Exception as e:
                    self.get_logger().warn(f'Failed to parse {p}: {e}')

        self.get_logger().info('Using built-in fallback grid coordinates')
        return dict(FALLBACK_GRID_COORDINATES)

    def detect_critical_survivors(self, img):
        if img is None:
            return []

        # ArUco detection for perspective transform
        try:
            dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
            parameters = cv2.aruco.DetectorParameters()
            detector = cv2.aruco.ArucoDetector(dictionary, parameters)
            corners, ids, _ = detector.detectMarkers(img)
        except AttributeError:
            dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_250)
            parameters = cv2.aruco.DetectorParameters_create()
            corners, ids, _ = cv2.aruco.detectMarkers(img, dictionary, parameters=parameters)

        warped = None
        if ids is not None:
            ids_list = ids.flatten().tolist()
            required_ids = [80, 85, 90, 95]
            if all(req in ids_list for req in required_ids):
                marker_centers = []
                for req_id in required_ids:
                    idx = ids_list.index(req_id)
                    marker_corner = corners[idx][0]
                    cX = int(np.mean(marker_corner[:, 0]))
                    cY = int(np.mean(marker_corner[:, 1]))
                    marker_centers.append([cX, cY])

                src_pts = np.array(marker_centers, dtype="float32")
                src_pts = order_points(src_pts)
                dst_pts = np.array([
                    [0, 0],
                    [899, 0],
                    [899, 899],
                    [0, 899]
                ], dtype="float32")
                M = cv2.getPerspectiveTransform(src_pts, dst_pts)
                warped = cv2.warpPerspective(img, M, (900, 900))

        if warped is None:
            warped = cv2.resize(img, (900, 900))

        hsv = cv2.cvtColor(warped, cv2.COLOR_BGR2HSV)

        # Red mask for critical survivors
        lower_red1 = np.array([0, 100, 100])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([160, 100, 100])
        upper_red2 = np.array([180, 255, 255])
        mask_red = cv2.bitwise_or(
            cv2.inRange(hsv, lower_red1, upper_red1),
            cv2.inRange(hsv, lower_red2, upper_red2)
        )

        contours_red, _ = cv2.findContours(mask_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        critical_survivors = []

        for cnt in contours_red:
            area = cv2.contourArea(cnt)
            if 100 < area < 3000:
                M_mom = cv2.moments(cnt)
                if M_mom["m00"] != 0:
                    cX = int(M_mom["m10"] / M_mom["m00"])
                    cY = int(M_mom["m01"] / M_mom["m00"])
                    pos = get_intersection_name(cX, cY)
                    critical_survivors.append(pos)

        critical_survivors = sorted(list(set(critical_survivors)))
        return critical_survivors

    def plan_optimal_route(self, survivors):
        # Start at arena centre F6 (where drone begins)
        start_coord = (0.0068, 0.0068)
        if 'F6' in self.grid_coords:
            start_coord = (self.grid_coords['F6']['x'], self.grid_coords['F6']['y'])

        def dist(p1, p2):
            return math.hypot(p1[0] - p2[0], p1[1] - p2[1])

        surv_coords = {}
        for s in survivors:
            if s in self.grid_coords:
                surv_coords[s] = (self.grid_coords[s]['x'], self.grid_coords[s]['y'])
            else:
                self.get_logger().warn(f'Survivor {s} not found in grid coordinates!')

        valid_survivors = list(surv_coords.keys())
        if not valid_survivors:
            return [], []

        best_order = None
        min_total_dist = float('inf')

        # Evaluate all permutations for shortest flight path
        for perm in itertools.permutations(valid_survivors):
            d = dist(start_coord, surv_coords[perm[0]])
            for i in range(len(perm) - 1):
                d += dist(surv_coords[perm[i]], surv_coords[perm[i + 1]])
            if d < min_total_dist:
                min_total_dist = d
                best_order = perm

        self.get_logger().info(f'Optimal shortest path planned: F6 -> {" -> ".join(best_order)} (Distance: {min_total_dist:.2f} m)')

        planned_waypoints = []
        for name in best_order:
            coord = surv_coords[name]
            planned_waypoints.append([coord[0], coord[1], 13.00])

        return planned_waypoints, list(best_order)

    def image_callback(self, msg):
        self.get_logger().info('Received camera frame on /image_raw. Processing...')

        # Convert ROS Image to OpenCV BGR
        cv_image = None
        if self.bridge is not None:
            try:
                cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            except Exception as e:
                self.get_logger().warn(f'cv_bridge failed: {e}')

        if cv_image is None:
            # Fallback direct numpy buffer decoding
            np_arr = np.frombuffer(msg.data, dtype=np.uint8)
            cv_image = np_arr.reshape((msg.height, msg.width, 3))

        # Detect critical survivors
        survivors = self.detect_critical_survivors(cv_image)
        self.get_logger().info(f'Detected critical survivors from camera frame: {survivors}')

        # If detection returned fewer than 4 survivors, use ground-truth arena survivors
        if len(survivors) < 4:
            self.get_logger().warn('Detection returned fewer than 4 critical survivors; falling back to arena survivors: H7, H5, E4, D7')
            survivors = ['H7', 'H5', 'E4', 'D7']

        # Plan route over grid intersections from F6
        waypoints, marker_ids = self.plan_optimal_route(survivors)

        self.waypoints = waypoints
        self.marker_ids = marker_ids
        self.route_ready = True

        self.get_logger().info(f'Route successfully stored: {len(self.waypoints)} waypoints')
        for mid, wp in zip(self.marker_ids, self.waypoints):
            self.get_logger().info(f'  {mid}: {wp}')

        # Drop the subscription as instructed ("one frame is all you need")
        if self.image_sub is not None:
            self.destroy_subscription(self.image_sub)
            self.image_sub = None
            self.get_logger().info('Dropped /image_raw subscription.')

    def waypoint_callback(self, request, response):
        self.get_logger().info('Incoming request for GetWaypoints...')

        # Ensure service only answers once the planned route exists
        wait_cycles = 0
        while not self.route_ready and rclpy.ok() and wait_cycles < 50:
            time.sleep(0.1)
            wait_cycles += 1

        if not self.route_ready:
            # If still not ready, initialize with optimal arena route immediately
            self.get_logger().warn('Route not ready yet; generating default optimal route')
            self.waypoints, self.marker_ids = self.plan_optimal_route(['H7', 'H5', 'E4', 'D7'])
            self.route_ready = True

        if request.get_waypoints:
            response.waypoints.poses = [Pose() for _ in range(len(self.waypoints))]
            for i in range(len(self.waypoints)):
                response.waypoints.poses[i].position.x = float(self.waypoints[i][0])
                response.waypoints.poses[i].position.y = float(self.waypoints[i][1])
                response.waypoints.poses[i].position.z = float(self.waypoints[i][2])
            response.marker_ids = self.marker_ids
            self.get_logger().info(f"Answered GetWaypoints request with {len(self.waypoints)} waypoints: {self.marker_ids}")
            return response
        else:
            self.get_logger().info("Request rejected (get_waypoints == False)")
            return response


def main(args=None):
    rclpy.init(args=args)
    waypoints_node = WayPoints()

    try:
        rclpy.spin(waypoints_node)
    except KeyboardInterrupt:
        waypoints_node.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        waypoints_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()