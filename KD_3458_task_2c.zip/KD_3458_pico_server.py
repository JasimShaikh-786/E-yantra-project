#!/usr/bin/env python3

import time
import math
try:
    from tf_transformations import euler_from_quaternion
except ImportError:
    def euler_from_quaternion(quaternion):
        x, y, z, w = quaternion
        sinr_cosp = 2.0 * (w * x + y * z)
        cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        sinp = 2.0 * (w * y - z * x)
        if abs(sinp) >= 1.0:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        return roll, pitch, yaw

import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

# Pico control specific libraries
from swift_msgs.msg import SwiftMsgs
from std_msgs.msg import Header
from whycode_interfaces.msg import MarkerArray
from error_msg.msg import Error
from controller_msg.msg import PIDTune
from nav_msgs.msg import Odometry

# Action interface
from waypoint_navigation.action import NavToWaypoint


class WayPointServer(Node):

    def __init__(self):
        super().__init__('waypoint_server')

        self.pid_callback_group = ReentrantCallbackGroup()
        self.action_callback_group = ReentrantCallbackGroup()
        self.sub_callback_group = ReentrantCallbackGroup()

        self.time_inside_sphere = 0.0
        self.max_time_inside_sphere = 0.0
        self.point_in_sphere_start_time = None
        self.duration = 0.0

        self.yaw = 0.0              # current yaw in degrees (updated from whycode)
        self.desired_yaw = -0.5     # target yaw angle (degrees)
        self.prev_yaw_error = 0.0

        self.curr_state = [0.0068, 0.0068, 15.0]     # drone starts on ground at z ~ 15.0
        self.desired_state = [0.0068, 0.0068, 15.0]  # initial ground state before first goal arrives
        self.drone_position = [0.0, 0.0, 15.0]
        self.dtime = 0.0
        self._got_position = False

        # Drone command message
        self.cmd = SwiftMsgs()
        self.cmd.rc_roll = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4 = 1500

        # Proven PID gains from Task 2A:
        # P = Kp * error
        # D = Kd * (error - previous_error)
        # I = Ki * sum(error)
        self.Kp = [14.0, 14.0, 35.0]
        self.Ki = [0.015, 0.015, 0.05]
        self.Kd = [180.0, 180.0, 240.0]

        self.prev_error = [0.0, 0.0, 0.0]
        self.error_sum = [0.0, 0.0, 0.0]

        self.max_values = [2000, 2000, 2000]
        self.min_values = [1000, 1000, 1000]

        self.pos_error = Error()
        self.sample_time = 0.033  # ~30 Hz, matching WhyCode rate

        # Publishers
        self.command_pub = self.create_publisher(SwiftMsgs, '/drone_command', 10)
        self.pos_error_pub = self.create_publisher(Error, '/pos_error', 10)
        self.heartbeat_pub = self.create_publisher(Header, '/controller_heartbeat', 10)

        # Subscribers
        self.create_subscription(
            MarkerArray,
            '/whycode_node/markers',
            self.whycode_callback,
            1,
            callback_group=self.sub_callback_group
        )

        self.create_subscription(
            Odometry,
            '/rotors/odometry',
            self.odometry_callback,
            10,
            callback_group=self.sub_callback_group
        )

        # Action server for NavToWaypoint, action name 'waypoint_navigation'
        self._action_server = ActionServer(
            self,
            NavToWaypoint,
            'waypoint_navigation',
            execute_callback=self.execute_callback,
            callback_group=self.action_callback_group
        )

        # Heartbeat timer (10 Hz)
        self.publish_heartbeat()
        self.create_timer(0.1, self.publish_heartbeat, callback_group=self.pid_callback_group)

        time.sleep(0.5)  # Let heartbeat reach rosbag before arming
        self.arm()

        # PID control loop timer
        self.timer = self.create_timer(
            self.sample_time,
            self.pid,
            callback_group=self.pid_callback_group
        )
        self.get_logger().info('Waypoint Action Server initialized and armed.')

    def publish_heartbeat(self):
        hb = Header()
        hb.stamp = self.get_clock().now().to_msg()
        hb.frame_id = 'pico_controller_active'
        self.heartbeat_pub.publish(hb)

    def disarm(self):
        self.cmd.rc_roll = 1000
        self.cmd.rc_yaw = 1000
        self.cmd.rc_pitch = 1000
        self.cmd.rc_throttle = 1000
        self.cmd.rc_aux4 = 1000
        self.command_pub.publish(self.cmd)

    def arm(self):
        self.disarm()
        self.cmd.rc_roll = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4 = 2000
        self.command_pub.publish(self.cmd)

    def whycode_callback(self, msg):
        if not msg.markers:
            return

        marker = msg.markers[0]
        position = marker.position.position
        self.curr_state = [position.x, position.y, position.z]
        self.drone_position = self.curr_state[:]

        # Yaw in degrees from whycode marker orientation
        self.yaw = math.degrees(marker.rotation.z)
        self.dtime = float(msg.header.stamp.sec) + float(msg.header.stamp.nanosec) * 1e-9
        self._got_position = True

    def odometry_callback(self, msg):
        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        roll, pitch, yaw = euler_from_quaternion(orientation_list)
        self.roll_deg = math.degrees(roll)
        self.pitch_deg = math.degrees(pitch)
        self.yaw_deg = math.degrees(yaw)

    def pid(self):
        if not self._got_position:
            return

        # Coordinate conventions:
        # X: Pitch (forward/back)
        # Y: Roll  (left/right)
        # Z: Altitude/throttle (ground ~ 15.0, fly ~ 13.0)
        pitch_err    = self.desired_state[0] - self.curr_state[0]
        roll_err     = self.desired_state[1] - self.curr_state[1]
        throttle_err = self.curr_state[2] - self.desired_state[2]

        errors = [roll_err, pitch_err, throttle_err]

        # Integral with anti-windup clamping
        for i in range(3):
            self.error_sum[i] += errors[i]
            self.error_sum[i] = max(-400.0, min(400.0, self.error_sum[i]))

        # Derivative
        d_error = [errors[i] - self.prev_error[i] for i in range(3)]

        # PID outputs (P + I + D)
        out_roll     = self.Kp[0] * errors[0] + self.Ki[0] * self.error_sum[0] + self.Kd[0] * d_error[0]
        out_pitch    = self.Kp[1] * errors[1] + self.Ki[1] * self.error_sum[1] + self.Kd[1] * d_error[1]
        out_throttle = self.Kp[2] * errors[2] + self.Ki[2] * self.error_sum[2] + self.Kd[2] * d_error[2]

        self.cmd.rc_roll     = int(1500 + out_roll)
        self.cmd.rc_pitch    = int(1500 + out_pitch)
        self.cmd.rc_throttle = int(1500 + out_throttle)
        self.cmd.rc_aux4     = 2000

        # Yaw PD control to maintain desired_yaw
        yaw_err = self.desired_yaw - self.yaw
        yaw_err = (yaw_err + 180.0) % 360.0 - 180.0
        d_yaw_err = yaw_err - self.prev_yaw_error
        out_yaw = 3.0 * yaw_err + 1.0 * d_yaw_err
        self.cmd.rc_yaw = int(1500 + out_yaw)
        self.prev_yaw_error = yaw_err

        # Clamp RC values to [1000, 2000]
        self.cmd.rc_roll     = max(self.min_values[0], min(self.max_values[0], self.cmd.rc_roll))
        self.cmd.rc_pitch    = max(self.min_values[1], min(self.max_values[1], self.cmd.rc_pitch))
        self.cmd.rc_throttle = max(self.min_values[2], min(self.max_values[2], self.cmd.rc_throttle))
        self.cmd.rc_yaw      = max(1000, min(2000, self.cmd.rc_yaw))

        self.command_pub.publish(self.cmd)

        # Publish error
        self.pos_error.roll_error     = float(roll_err)
        self.pos_error.pitch_error    = float(pitch_err)
        self.pos_error.throttle_error = float(throttle_err)
        self.pos_error.yaw_error      = float(yaw_err)
        self.pos_error_pub.publish(self.pos_error)

        self.prev_error = errors[:]

    def is_drone_in_sphere(self, drone_pos, goal_handle, radius=0.4):
        target = goal_handle.request.waypoint.position
        dx = abs(drone_pos[0] - target.x)
        dy = abs(drone_pos[1] - target.y)
        dz = abs(drone_pos[2] - target.z)
        # Check both axis-aligned box (±0.4) and Euclidean distance
        in_box = (dx <= radius and dy <= radius and dz <= radius)
        return in_box

    def execute_callback(self, goal_handle):
        self.get_logger().info('Executing goal...')
        self.desired_state[0] = goal_handle.request.waypoint.position.x
        self.desired_state[1] = goal_handle.request.waypoint.position.y
        self.desired_state[2] = goal_handle.request.waypoint.position.z

        self.get_logger().info(f'New Waypoint Set: {self.desired_state}')
        self.max_time_inside_sphere = 0.0
        self.point_in_sphere_start_time = None
        self.time_inside_sphere = 0.0
        self.duration = self.dtime if self.dtime > 0 else time.time()

        feedback_msg = NavToWaypoint.Feedback()

        rate_sleep = 0.05  # 20 Hz feedback loop
        while rclpy.ok():
            feedback_msg.current_waypoint.pose.position.x = float(self.curr_state[0])
            feedback_msg.current_waypoint.pose.position.y = float(self.curr_state[1])
            feedback_msg.current_waypoint.pose.position.z = float(self.curr_state[2])
            feedback_msg.current_waypoint.header.stamp.sec = int(self.max_time_inside_sphere)

            goal_handle.publish_feedback(feedback_msg)

            # Tolerance: ±0.4 whycode units as specified in Task 2B instructions
            drone_is_in_sphere = self.is_drone_in_sphere(self.drone_position, goal_handle, 0.4)
            current_time = self.dtime if self.dtime > 0 else time.time()

            if not drone_is_in_sphere and self.point_in_sphere_start_time is None:
                pass
            elif drone_is_in_sphere and self.point_in_sphere_start_time is None:
                self.point_in_sphere_start_time = current_time
                self.get_logger().info('Drone in sphere for 1st time')
            elif drone_is_in_sphere and self.point_in_sphere_start_time is not None:
                self.time_inside_sphere = current_time - self.point_in_sphere_start_time
            elif not drone_is_in_sphere and self.point_in_sphere_start_time is not None:
                self.get_logger().info('Drone out of sphere')
                self.point_in_sphere_start_time = None
                self.time_inside_sphere = 0.0

            if self.time_inside_sphere > self.max_time_inside_sphere:
                self.max_time_inside_sphere = self.time_inside_sphere

            # Reached hold condition: 3 continuous seconds
            if self.max_time_inside_sphere >= 3.0:
                self.get_logger().info(f'Waypoint {self.desired_state} held successfully for 3s!')
                break

            time.sleep(rate_sleep)

        goal_handle.succeed()

        result = NavToWaypoint.Result()
        current_time = self.dtime if self.dtime > 0 else time.time()
        result.hov_time = int(current_time - self.duration)
        return result


def main(args=None):
    rclpy.init(args=args)

    waypoint_server = WayPointServer()
    executor = MultiThreadedExecutor()
    executor.add_node(waypoint_server)

    try:
        executor.spin()
    except KeyboardInterrupt:
        waypoint_server.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        waypoint_server.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
