#!/usr/bin/env python3


# This script is used to run the first task 1A of Khojo Drone.

# You will be building the image processing pipeline for the drone. The pipeline will take in an image and output a txt file. 

import cv2
import numpy as np
import argparse
import os

def order_points(pts):
    # helper to grab points in a consistent order: top-left, top-right, bottom-right, bottom-left
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)] # top-left
    rect[2] = pts[np.argmax(s)] # bottom-right
    
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)] # top-right
    rect[3] = pts[np.argmax(diff)] # bottom-left
    return rect

def get_intersection_name(cx, cy):
    # each grid cell is 75 pixels (900 / 12)
    # intersections start from 75,75 so we divide and round off
    col_idx = int(round(cx / 75.0)) - 1
    row_idx = int(round(cy / 75.0)) - 1
    
    # clamping just in case it goes out of bounds
    col_idx = max(0, min(10, col_idx))
    row_idx = max(0, min(10, row_idx))
    
    # 'A' is 65 in ascii
    col_letter = chr(65 + col_idx)
    row_number = row_idx + 1
    return f"{col_letter}{row_number}"

def main():
    # setup arg parser for taking image path from terminal
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', required=True, help="input image path")
    args = parser.parse_args()
    
    image_path = args.image
    img = cv2.imread(image_path)
    
    if img is None:
        print("Failed to load image!")
        exit(1)

    # --- VERSION COMPATIBILITY FIX FOR ARUCO ---
    try:
        # Newer OpenCV (v4.7+) - Runs on your local laptop
        dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
        parameters = cv2.aruco.DetectorParameters()
        detector = cv2.aruco.ArucoDetector(dictionary, parameters)
        corners, ids, rejected = detector.detectMarkers(img)
    except AttributeError:
        # Older OpenCV (v4.6 or older) - Runs on the e-Yantra grader
        dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_250)
        parameters = cv2.aruco.DetectorParameters_create()
        corners, ids, rejected = cv2.aruco.detectMarkers(img, dictionary, parameters=parameters)
    # -------------------------------------------
    
    if ids is None:
        print("No markers found in the image")
        exit(1)
        
    ids = ids.flatten().tolist()
    required_ids = [80, 85, 90, 95]
    
    # make sure we have all 4 markers before proceeding
    if not all(req in ids for req in required_ids):
        print("Missing some required markers")
        exit(1)
        
    # extract the center of each required marker
    marker_centers = []
    for req_id in required_ids:
        idx = ids.index(req_id)
        marker_corner = corners[idx][0]
        # avg of corners to get the exact center
        cX = int(np.mean(marker_corner[:, 0]))
        cY = int(np.mean(marker_corner[:, 1]))
        marker_centers.append([cX, cY])
        
    # perspective transform to flatten the arena
    src_pts = np.array(marker_centers, dtype="float32")
    src_pts = order_points(src_pts)
    
    # mapping to a flat 900x900 square image
    dst_pts = np.array([
        [0, 0],
        [899, 0],
        [899, 899],
        [0, 899]
    ], dtype="float32")
    
    M = cv2.getPerspectiveTransform(src_pts, dst_pts)
    warped = cv2.warpPerspective(img, M, (900, 900))
    
    # finding survivors using HSV color masking
    hsv = cv2.cvtColor(warped, cv2.COLOR_BGR2HSV)
    
    # yellow mask (for stable survivors)
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([40, 255, 255])
    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
    
    # red mask (for critical survivors) - red wraps around in HSV
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([180, 255, 255])
    
    mask_red = cv2.bitwise_or(
        cv2.inRange(hsv, lower_red1, upper_red1),
        cv2.inRange(hsv, lower_red2, upper_red2)
    )
    
    # finding contours to locate the colored dots
    contours_yellow, _ = cv2.findContours(mask_yellow, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours_red, _ = cv2.findContours(mask_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    stable_survivors = []
    critical_survivors = []
    
    # processing yellow dots
    for cnt in contours_yellow:
        area = cv2.contourArea(cnt)
        if area > 50: # Standard area check for yellow to ensure we don't drop them
            M_moments = cv2.moments(cnt)
            if M_moments["m00"] != 0:
                cX = int(M_moments["m10"] / M_moments["m00"])
                cY = int(M_moments["m01"] / M_moments["m00"])
                pos = get_intersection_name(cX, cY)
                stable_survivors.append(pos)
                
    # processing red dots
    for cnt in contours_red:
        area = cv2.contourArea(cnt)
        if 150 < area < 1500: # Tighten area for red to ignore tiny noise and large background logos
            M_moments = cv2.moments(cnt)
            if M_moments["m00"] != 0:
                cX = int(M_moments["m10"] / M_moments["m00"])
                cY = int(M_moments["m01"] / M_moments["m00"])
                pos = get_intersection_name(cX, cY)
                critical_survivors.append(pos)

    # removing duplicate coordinates using set()
    critical_survivors = list(set(critical_survivors))
    stable_survivors = list(set(stable_survivors))

    # sorting them so the final txt file looks neat
    critical_survivors.sort()
    stable_survivors.sort()

    # save everything to the results text file
    base_name = os.path.splitext(image_path)[0]
    output_filename = f"{base_name}_results.txt"
    
    with open(output_filename, 'w') as f:
        f.write(f"Detected marker IDs: {ids}\n\n")
        f.write(f"Critical Survivors: {', '.join(critical_survivors)}\n")
        f.write(f"Stable Survivors: {', '.join(stable_survivors)}\n")

if __name__ == "__main__":
    main()


