#!/usr/bin/env python3

'''
This python file runs a ROS 2-node of name pico_controller which holds the position of Swift Pico Drone
at the given setpoint (1.5, -1.5, 13).

This node publishes and subscribes the following topics:

        PUBLICATIONS                SUBSCRIPTIONS
        /drone_command              /whycode_node/markers
        /pos_error                  /throttle_pid
        /controller_heartbeat       /pitch_pid
                                    /roll_pid
'''

from swift_msgs.msg import SwiftMsgs
from whycode_interfaces.msg import MarkerArray
from controller_msg.msg import PIDTune
from error_msg.msg import Error
from std_msgs.msg import Header
import time
import rclpy
from rclpy.node import Node


class Swift_Pico(Node):
    def __init__(self):
        super().__init__('pico_controller')

        # Current position of drone [x, y, z] from whycode
        self.current_state = [0.0, 0.0, 0.0]

        # Desired setpoint: [X (pitch), Y (roll), Z (throttle)]
        self.desired_state = [1.5, -1.5, 13.0]

        # Drone command message
        self.cmd = SwiftMsgs()
        self.cmd.rc_roll = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4 = 1500

        # Exact e-Yantra formulas from Task 2A instructions:
        # P = Kp * error
        # D = Kd * (error - previous_error)
        # I = Ki * sum(error)
        # Using tuned Task 1C gains:
        self.Kp = [14.0, 14.0, 35.0]
        self.Ki = [0.015, 0.015, 0.05]
        self.Kd = [180.0, 180.0, 240.0]

        # State variables for PID [roll, pitch, throttle]
        self.prev_error = [0.0, 0.0, 0.0]
        self.error_sum  = [0.0, 0.0, 0.0]

        # Clamping limits
        self.max_values = [2000, 2000, 2000]
        self.min_values = [1000, 1000, 1000]

        self.pos_error = Error()
        self.sample_time = 0.033  # seconds (~30 Hz)

        self._got_position = False

        # Publishers
        self.command_pub   = self.create_publisher(SwiftMsgs, '/drone_command', 10)
        self.pos_error_pub = self.create_publisher(Error, '/pos_error', 10)
        self.heartbeat_pub = self.create_publisher(Header, '/controller_heartbeat', 10)

        # Subscribers
        self.create_subscription(MarkerArray, '/whycode_node/markers', self.whycode_callback, 1)
        self.create_subscription(PIDTune, '/throttle_pid', self.altitude_set_pid, 1)
        self.create_subscription(PIDTune, '/pitch_pid',    self.pitch_set_pid,    1)
        self.create_subscription(PIDTune, '/roll_pid',     self.roll_set_pid,     1)

        # Heartbeat timer (10 Hz)
        self.publish_heartbeat()
        self.create_timer(0.1, self.publish_heartbeat)

        time.sleep(0.5)
        self.arm()

        # PID timer
        self.create_timer(self.sample_time, self.pid)

    def publish_heartbeat(self):
        hb = Header()
        hb.stamp = self.get_clock().now().to_msg()
        hb.frame_id = 'pico_controller_active'
        self.heartbeat_pub.publish(hb)

    def disarm(self):
        self.cmd.rc_roll     = 1000
        self.cmd.rc_yaw      = 1000
        self.cmd.rc_pitch    = 1000
        self.cmd.rc_throttle = 1000
        self.cmd.rc_aux4     = 1000
        self.command_pub.publish(self.cmd)

    def arm(self):
        self.disarm()
        self.cmd.rc_roll     = 1500
        self.cmd.rc_yaw      = 1500
        self.cmd.rc_pitch    = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4     = 2000
        self.command_pub.publish(self.cmd)

    def whycode_callback(self, msg):
        if not msg.markers:
            return
        self.current_state[0] = msg.markers[0].position.position.x  # X (Pitch axis)
        self.current_state[1] = msg.markers[0].position.position.y  # Y (Roll axis)
        self.current_state[2] = msg.markers[0].position.position.z  # Z (Throttle axis)
        self._got_position = True

    def altitude_set_pid(self, alt):
        self.Kp[2] = alt.kp * 0.03
        self.Ki[2] = alt.ki * 0.008
        self.Kd[2] = alt.kd * 0.6

    def pitch_set_pid(self, pitch):
        self.Kp[1] = pitch.kp * 0.03
        self.Ki[1] = pitch.ki * 0.008
        self.Kd[1] = pitch.kd * 0.6

    def roll_set_pid(self, roll):
        self.Kp[0] = roll.kp * 0.03
        self.Ki[0] = roll.ki * 0.008
        self.Kd[0] = roll.kd * 0.6

    def pid(self):
        if not self._got_position:
            return

        # Coordinate conventions:
        # Camera is mounted above facing down:
        # X: Pitch (forward/back) -> desired = +1.5
        # Y: Roll  (left/right)   -> desired = -1.5
        # Z: Altitude/throttle    -> ground = 15.0, desired = 13.0
        
        pitch_err    = self.desired_state[0] - self.current_state[0]
        roll_err     = self.desired_state[1] - self.current_state[1]
        throttle_err = self.current_state[2] - self.desired_state[2]

        errors = [roll_err, pitch_err, throttle_err]

        # Integral with anti-windup clamping (only integrate when within range)
        for i in range(3):
            self.error_sum[i] += errors[i]
            self.error_sum[i] = max(-400.0, min(400.0, self.error_sum[i]))

        # Exact e-Yantra formula from Screenshot 19:00:28:
        # D = Kd * (error - previous_error)
        d_error = [errors[i] - self.prev_error[i] for i in range(3)]

        # PID outputs (P + I + D)
        out_roll     = self.Kp[0] * errors[0] + self.Ki[0] * self.error_sum[0] + self.Kd[0] * d_error[0]
        out_pitch    = self.Kp[1] * errors[1] + self.Ki[1] * self.error_sum[1] + self.Kd[1] * d_error[1]
        out_throttle = self.Kp[2] * errors[2] + self.Ki[2] * self.error_sum[2] + self.Kd[2] * d_error[2]

        # Map to RC signals:
        # roll_err < 0  -> wants to go towards -1.5 (left)   -> rc_roll < 1500  -> 1500 + out_roll
        # pitch_err > 0 -> wants to go towards +1.5 (forward)-> rc_pitch > 1500 -> 1500 + out_pitch
        # throttle_err > 0 -> wants to climb towards 13.0    -> rc_throttle > 1500 -> 1500 + out_throttle
        self.cmd.rc_roll     = int(1500 + out_roll)
        self.cmd.rc_pitch    = int(1500 + out_pitch)
        self.cmd.rc_throttle = int(1500 + out_throttle)
        self.cmd.rc_aux4     = 2000  # Armed

        # Clamp to [1000, 2000]
        self.cmd.rc_roll     = max(self.min_values[0], min(self.max_values[0], self.cmd.rc_roll))
        self.cmd.rc_pitch    = max(self.min_values[1], min(self.max_values[1], self.cmd.rc_pitch))
        self.cmd.rc_throttle = max(self.min_values[2], min(self.max_values[2], self.cmd.rc_throttle))

        self.command_pub.publish(self.cmd)

        # Publish errors for evaluation
        self.pos_error.roll_error     = float(roll_err)
        self.pos_error.pitch_error    = float(pitch_err)
        self.pos_error.throttle_error = float(throttle_err)
        self.pos_error.yaw_error      = 0.0
        self.pos_error_pub.publish(self.pos_error)

        self.prev_error = errors[:]


def main(args=None):
    rclpy.init(args=args)
    swift_pico = Swift_Pico()

    try:
        rclpy.spin(swift_pico)
    except KeyboardInterrupt:
        swift_pico.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        swift_pico.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
