#!/usr/bin/env python3

import os
import json
import csv
import math
import heapq
import itertools
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from geometry_msgs.msg import Pose, Point
from sensor_msgs.msg import Image
from waypoint_navigation.srv import GetWaypoints, ReplanWaypoints
from ament_index_python.packages import get_package_share_directory

try:
    from cv_bridge import CvBridge
except ImportError:
    CvBridge = None

import cv2
import numpy as np

# Built-in arena grid intersection coordinates (WhyCode units)
FALLBACK_GRID_COORDINATES = {
    'A1': {'x': 6.1131, 'y': 6.1131}, 'B1': {'x': 4.9049, 'y': 6.1306}, 'C1': {'x': 3.6785, 'y': 6.1265}, 'D1': {'x': 2.4153, 'y': 6.025},
    'E1': {'x': 1.2113, 'y': 6.0221}, 'F1': {'x': 0.0068, 'y': 6.0941}, 'G1': {'x': -1.1982, 'y': 6.0255}, 'H1': {'x': -2.4025, 'y': 6.0271},
    'I1': {'x': -3.6743, 'y': 6.1415}, 'J1': {'x': -4.8826, 'y': 6.1194}, 'K1': {'x': -6.096, 'y': 6.1096}, 'A2': {'x': 6.1239, 'y': 4.8995},
    'B2': {'x': 4.88, 'y': 4.88}, 'C2': {'x': 3.6914, 'y': 4.9202}, 'D2': {'x': 2.4376, 'y': 4.8662}, 'E2': {'x': 1.2032, 'y': 4.7897},
    'F2': {'x': 0.0067, 'y': 4.7898}, 'G2': {'x': -1.1913, 'y': 4.795}, 'H2': {'x': -2.4241, 'y': 4.8663}, 'I2': {'x': -3.6835, 'y': 4.9279},
    'J2': {'x': -4.8661, 'y': 4.8796}, 'K2': {'x': -6.11, 'y': 4.8996}, 'A3': {'x': 6.126, 'y': 3.6781}, 'B3': {'x': 4.9186, 'y': 3.6902},
    'C3': {'x': 3.7042, 'y': 3.7042}, 'D3': {'x': 2.4595, 'y': 3.6857}, 'E3': {'x': 1.2098, 'y': 3.6139}, 'F3': {'x': 0.0066, 'y': 3.5752},
    'G3': {'x': -1.197, 'y': 3.6157}, 'H3': {'x': -2.4447, 'y': 3.6835}, 'I3': {'x': -3.687, 'y': 3.7007}, 'J3': {'x': -4.9155, 'y': 3.6987},
    'K3': {'x': -6.1124, 'y': 3.6782}, 'A4': {'x': 6.0201, 'y': 2.4134}, 'B4': {'x': 4.865, 'y': 2.437}, 'C4': {'x': 3.6843, 'y': 2.4588},
    'D4': {'x': 2.4454, 'y': 2.4454}, 'E4': {'x': 1.222, 'y': 2.4388}, 'F4': {'x': 0.0067, 'y': 2.3998}, 'G4': {'x': -1.201, 'y': 2.422},
    'H4': {'x': -2.4323, 'y': 2.4459}, 'I4': {'x': -3.6699, 'y': 2.458}, 'J4': {'x': -4.8559, 'y': 2.4392}, 'K4': {'x': -6.0101, 'y': 2.4148},
    'A5': {'x': 6.001, 'y': 1.2067}, 'B5': {'x': 4.7948, 'y': 1.2046}, 'C5': {'x': 3.6154, 'y': 1.2102}, 'D5': {'x': 2.4396, 'y': 1.2226},
    'E5': {'x': 1.1989, 'y': 1.1992}, 'F5': {'x': 0.0067, 'y': 1.2142}, 'G5': {'x': -1.1865, 'y': 1.2001}, 'H5': {'x': -2.4256, 'y': 1.2222},
    'I5': {'x': -3.5968, 'y': 1.2085}, 'J5': {'x': -4.8074, 'y': 1.2106}, 'K5': {'x': -5.9959, 'y': 1.2084}, 'A6': {'x': 6.0404, 'y': 0.0067},
    'B6': {'x': 4.7881, 'y': 0.0067}, 'C6': {'x': 3.5627, 'y': 0.0066}, 'D6': {'x': 2.3995, 'y': 0.0067}, 'E6': {'x': 1.2148, 'y': 0.0067},
    'F6': {'x': 0.0068, 'y': 0.0068}, 'G6': {'x': -1.1955, 'y': 0.0067}, 'H6': {'x': -2.3868, 'y': 0.0067}, 'I6': {'x': -3.5459, 'y': 0.0066},
    'J6': {'x': -4.776, 'y': 0.0067}, 'K6': {'x': -6.0264, 'y': 0.0067}, 'A7': {'x': 6.0239, 'y': -1.1979}, 'B7': {'x': 4.79, 'y': -1.19},
    'C7': {'x': 3.6105, 'y': -1.1951}, 'D7': {'x': 2.4365, 'y': -1.2074}, 'E7': {'x': 1.1982, 'y': -1.1852}, 'F7': {'x': 0.0067, 'y': -1.2005},
    'G7': {'x': -1.1862, 'y': -1.1859}, 'H7': {'x': -2.4221, 'y': -1.2071}, 'I7': {'x': -3.5994, 'y': -1.1959}, 'J7': {'x': -4.7958, 'y': -1.1943},
    'K7': {'x': -6.0118, 'y': -1.1982}, 'A8': {'x': 6.0348, 'y': -2.4055}, 'B8': {'x': 4.8663, 'y': -2.4241}, 'C8': {'x': 3.6845, 'y': -2.4453},
    'D8': {'x': 2.4467, 'y': -2.4331}, 'E8': {'x': 1.2227, 'y': -2.4266}, 'F8': {'x': 0.0067, 'y': -2.3863}, 'G8': {'x': -1.2004, 'y': -2.4073},
    'H8': {'x': -2.4297, 'y': -2.4297}, 'I8': {'x': -3.6729, 'y': -2.4467}, 'J8': {'x': -4.855, 'y': -2.4252}, 'K8': {'x': -6.011, 'y': -2.4015},
    'A9': {'x': 6.1051, 'y': -3.6516}, 'B9': {'x': 4.9322, 'y': -3.6867}, 'C9': {'x': 3.7015, 'y': -3.6878}, 'D9': {'x': 2.4583, 'y': -3.6703},
    'E9': {'x': 1.2109, 'y': -3.6036}, 'F9': {'x': 0.0066, 'y': -3.5459}, 'G9': {'x': -1.197, 'y': -3.6026}, 'H9': {'x': -2.4472, 'y': -3.6737},
    'I9': {'x': -3.6853, 'y': -3.6853}, 'J9': {'x': -4.9174, 'y': -3.6862}, 'K9': {'x': -6.0899, 'y': -3.6506}, 'A10': {'x': 6.1247, 'y': -4.8866},
    'B10': {'x': 4.881, 'y': -4.8674}, 'C10': {'x': 3.6923, 'y': -4.9076}, 'D10': {'x': 2.4377, 'y': -4.853}, 'E10': {'x': 1.204, 'y': -4.7795},
    'F10': {'x': 0.0067, 'y': -4.775}, 'G10': {'x': -1.1908, 'y': -4.7798}, 'H10': {'x': -2.4194, 'y': -4.8433}, 'I10': {'x': -3.6834, 'y': -4.914},
    'J10': {'x': -4.8643, 'y': -4.8643}, 'K10': {'x': -6.1201, 'y': -4.894}, 'A11': {'x': 6.1097, 'y': -6.0961}, 'B11': {'x': 4.8986, 'y': -6.1088},
    'C11': {'x': 3.6792, 'y': -6.114}, 'D11': {'x': 2.415, 'y': -6.0108}, 'E11': {'x': 1.2085, 'y': -5.997}, 'F11': {'x': 0.0068, 'y': -6.085},
    'G11': {'x': -1.1973, 'y': -6.0073}, 'H11': {'x': -2.4056, 'y': -6.0206}, 'I11': {'x': -3.6603, 'y': -6.1052}, 'J11': {'x': -4.896, 'y': -6.1226},
    'K11': {'x': -6.1156, 'y': -6.1156}
}

COLS = [chr(65 + i) for i in range(11)]
ROWS = [i + 1 for i in range(11)]


def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # top-left
    rect[2] = pts[np.argmax(s)]  # bottom-right
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  # top-right
    rect[3] = pts[np.argmax(diff)]  # bottom-left
    return rect


def get_intersection_name(cx, cy):
    col_idx = int(round(cx / 75.0)) - 1
    row_idx = int(round(cy / 75.0)) - 1
    col_idx = max(0, min(10, col_idx))
    row_idx = max(0, min(10, row_idx))
    return f"{chr(65 + col_idx)}{row_idx + 1}"


class WayPoints(Node):

    def __init__(self):
        super().__init__('waypoints_service')

        self.grid_coords = self.load_grid_coordinates()
        self.critical_survivors = []
        self.stable_survivors = []
        self.obstacles = []

        self.critical_waypoints = []
        self.critical_marker_ids = []
        self.critical_route_ready = False

        if CvBridge is not None:
            self.bridge = CvBridge()
        else:
            self.bridge = None

        # Subscribe to /image_raw (transient local, reliable QoS)
        qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL
        )
        self.image_sub = self.create_subscription(
            Image,
            '/image_raw',
            self.image_callback,
            qos
        )
        self.get_logger().info('Subscribed to /image_raw. Waiting for arena camera frame...')

        # Service server for GetWaypoints (Critical Route)
        self.srv_get = self.create_service(GetWaypoints, 'waypoints', self.get_waypoints_callback)

        # Service server for ReplanWaypoints (Stable Route from current position)
        self.srv_replan = self.create_service(ReplanWaypoints, 'replan_waypoints', self.replan_waypoints_callback)

        self.get_logger().info('Waypoint services (waypoints, replan_waypoints) ready.')

    def load_grid_coordinates(self):
        candidate_paths = [
            os.path.expanduser('~/pico_ws/src/swift_pico/scripts/grid_whycode_coordinates.csv'),
            os.path.expanduser('~/pico_ws/src/swift_pico/src/grid_whycode_coordinates.json'),
            '/home/tanishq/pico_ws/src/swift_pico/scripts/grid_whycode_coordinates.csv',
            '/home/tanishq/pico_ws/src/swift_pico/src/grid_whycode_coordinates.json',
        ]
        try:
            share_dir = get_package_share_directory('swift_pico')
            candidate_paths.insert(0, os.path.join(share_dir, 'scripts', 'grid_whycode_coordinates.csv'))
            candidate_paths.insert(1, os.path.join(share_dir, 'scripts', 'grid_whycode_coordinates.json'))
        except Exception:
            pass

        for p in candidate_paths:
            if os.path.exists(p):
                try:
                    if p.endswith('.json'):
                        with open(p, 'r') as f:
                            grid = json.load(f)
                            self.get_logger().info(f'Loaded grid coordinates from {p}')
                            return grid
                    elif p.endswith('.csv'):
                        with open(p, 'r') as f:
                            reader = csv.DictReader(f)
                            grid = {row['intersection']: {'x': float(row['x']), 'y': float(row['y'])} for row in reader}
                            self.get_logger().info(f'Loaded grid coordinates from {p}')
                            return grid
                except Exception as e:
                    self.get_logger().warn(f'Failed to parse {p}: {e}')

        self.get_logger().info('Using built-in fallback grid coordinates')
        return dict(FALLBACK_GRID_COORDINATES)

    def is_point_safe(self, pt, clearance=0.0):
        for obs in self.obstacles:
            c = obs['center']
            r = obs['radius']
            if math.hypot(pt[0] - c[0], pt[1] - c[1]) < (r + clearance):
                return False
        return True

    def is_segment_safe(self, p1, p2, num_checks=30):
        for i in range(num_checks + 1):
            t = i / float(num_checks)
            px = p1[0] + t * (p2[0] - p1[0])
            py = p1[1] + t * (p2[1] - p1[1])
            if not self.is_point_safe((px, py)):
                return False
        return True

    def get_neighbors(self, node_name, safe_nodes):
        c, r = node_name[0], int(node_name[1:])
        ci, ri = COLS.index(c), ROWS.index(r)
        nbrs = []
        for dci in [-1, 0, 1]:
            for dri in [-1, 0, 1]:
                if dci == 0 and dri == 0:
                    continue
                nci, nri = ci + dci, ri + dri
                if 0 <= nci < 11 and 0 <= nri < 11:
                    nbr_name = f"{COLS[nci]}{ROWS[nri]}"
                    if nbr_name in safe_nodes:
                        p1 = (safe_nodes[node_name]['x'], safe_nodes[node_name]['y'])
                        p2 = (safe_nodes[nbr_name]['x'], safe_nodes[nbr_name]['y'])
                        if self.is_segment_safe(p1, p2):
                            nbrs.append((nbr_name, math.hypot(p1[0] - p2[0], p1[1] - p2[1])))
        return nbrs

    def plan_path_between(self, start_node, goal_node):
        p1 = (self.grid_coords[start_node]['x'], self.grid_coords[start_node]['y'])
        p2 = (self.grid_coords[goal_node]['x'], self.grid_coords[goal_node]['y'])

        if self.is_segment_safe(p1, p2):
            return [start_node, goal_node]

        safe_nodes = {k: v for k, v in self.grid_coords.items() if self.is_point_safe((v['x'], v['y']))}
        if start_node not in safe_nodes:
            safe_nodes[start_node] = self.grid_coords[start_node]
        if goal_node not in safe_nodes:
            safe_nodes[goal_node] = self.grid_coords[goal_node]

        pq = [(0.0, start_node, [start_node])]
        visited = {}
        while pq:
            cost, curr, path = heapq.heappop(pq)
            if curr == goal_node:
                # 1. Try single intermediate waypoint that minimizes total distance
                best_mid = None
                best_len = float('inf')
                for mid in path[1:-1]:
                    pm = (self.grid_coords[mid]['x'], self.grid_coords[mid]['y'])
                    if self.is_segment_safe(p1, pm) and self.is_segment_safe(pm, p2):
                        d = math.hypot(p1[0] - pm[0], p1[1] - pm[1]) + math.hypot(pm[0] - p2[0], pm[1] - p2[1])
                        if d < best_len:
                            best_len = d
                            best_mid = mid
                if best_mid:
                    return [start_node, best_mid, goal_node]

                # 2. General multi-hop shortcut fallback
                simplified = [path[0]]
                curr_idx = 0
                while curr_idx < len(path) - 1:
                    next_idx = len(path) - 1
                    while next_idx > curr_idx + 1:
                        cp1 = (self.grid_coords[path[curr_idx]]['x'], self.grid_coords[path[curr_idx]]['y'])
                        cp2 = (self.grid_coords[path[next_idx]]['x'], self.grid_coords[path[next_idx]]['y'])
                        if self.is_segment_safe(cp1, cp2):
                            break
                        next_idx -= 1
                    simplified.append(path[next_idx])
                    curr_idx = next_idx
                return simplified

            if curr in visited and visited[curr] <= cost:
                continue
            visited[curr] = cost

            for nbr, dist in self.get_neighbors(curr, safe_nodes):
                nc = cost + dist
                if nbr not in visited or nc < visited[nbr]:
                    h = math.hypot(self.grid_coords[nbr]['x'] - p2[0], self.grid_coords[nbr]['y'] - p2[1])
                    heapq.heappush(pq, (nc + h, nbr, path + [nbr]))

        return [start_node, goal_node]

    def find_closest_grid_node(self, pos):
        best_node = 'F6'
        min_d = float('inf')
        for node, c in self.grid_coords.items():
            if self.is_point_safe((c['x'], c['y'])):
                d = math.hypot(pos[0] - c['x'], pos[1] - c['y'])
                if d < min_d:
                    min_d = d
                    best_node = node
        return best_node

    def plan_sequence(self, start_node, targets, end_node=None):
        best_dist = float('inf')
        best_route_nodes = []
        target_set = set(targets)
        if end_node:
            target_set.add(end_node)

        for perm in itertools.permutations(targets):
            sequence = [start_node] + list(perm)
            if end_node:
                sequence.append(end_node)
            route = []
            tot_d = 0.0
            for i in range(len(sequence) - 1):
                seg = self.plan_path_between(sequence[i], sequence[i + 1])
                for j in range(len(seg) - 1):
                    p1 = (self.grid_coords[seg[j]]['x'], self.grid_coords[seg[j]]['y'])
                    p2 = (self.grid_coords[seg[j + 1]]['x'], self.grid_coords[seg[j + 1]]['y'])
                    tot_d += math.hypot(p1[0] - p2[0], p1[1] - p2[1])
                if i == 0:
                    route.extend(seg)
                else:
                    route.extend(seg[1:])
            if tot_d < best_dist:
                best_dist = tot_d
                best_route_nodes = route

        waypoints = []
        marker_ids = []
        for name in best_route_nodes:
            if name == start_node and len(waypoints) == 0:
                continue  # don't re-send start node if starting there
            c = self.grid_coords[name]
            waypoints.append([c['x'], c['y'], 13.0])
            if name in target_set:
                marker_ids.append(name)
            else:
                marker_ids.append(f"TRANSIT_{name}")

        return waypoints, marker_ids

    def image_callback(self, msg):
        self.get_logger().info('Received camera frame on /image_raw. Detecting survivors & obstacles...')

        cv_image = None
        if self.bridge is not None:
            try:
                cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            except Exception as e:
                self.get_logger().warn(f'cv_bridge failed: {e}')

        if cv_image is None:
            np_arr = np.frombuffer(msg.data, dtype=np.uint8)
            cv_image = np_arr.reshape((msg.height, msg.width, 3))

        # Detect ArUco markers 80, 85, 90, 95
        try:
            dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
            parameters = cv2.aruco.DetectorParameters()
            detector = cv2.aruco.ArucoDetector(dictionary, parameters)
            corners, ids, _ = detector.detectMarkers(cv_image)
        except AttributeError:
            dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_250)
            parameters = cv2.aruco.DetectorParameters_create()
            corners, ids, _ = cv2.aruco.detectMarkers(cv_image, dictionary, parameters=parameters)

        warped = None
        if ids is not None:
            ids_list = ids.flatten().tolist()
            required_ids = [80, 85, 90, 95]
            if all(req in ids_list for req in required_ids):
                marker_centers = []
                for req_id in required_ids:
                    idx = ids_list.index(req_id)
                    mc = corners[idx][0]
                    marker_centers.append([int(np.mean(mc[:, 0])), int(np.mean(mc[:, 1]))])

                src_pts = order_points(np.array(marker_centers, dtype="float32"))
                dst_pts = np.array([[0, 0], [899, 0], [899, 899], [0, 899]], dtype="float32")
                M = cv2.getPerspectiveTransform(src_pts, dst_pts)
                warped = cv2.warpPerspective(cv_image, M, (900, 900))

        if warped is None:
            warped = cv2.resize(cv_image, (900, 900))

        hsv = cv2.cvtColor(warped, cv2.COLOR_BGR2HSV)

        # Red mask for Critical Survivors
        lower_red1, upper_red1 = np.array([0, 100, 100]), np.array([10, 255, 255])
        lower_red2, upper_red2 = np.array([160, 100, 100]), np.array([180, 255, 255])
        mask_red = cv2.bitwise_or(cv2.inRange(hsv, lower_red1, upper_red1), cv2.inRange(hsv, lower_red2, upper_red2))

        # Yellow mask for Stable Survivors
        lower_yellow, upper_yellow = np.array([20, 100, 100]), np.array([35, 255, 255])
        mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)

        # Black mask for 3D Obstacles
        gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
        mask_black = cv2.inRange(gray, 0, 45)

        # Extract Critical Survivors
        crit = []
        for c in cv2.findContours(mask_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
            if 500 < cv2.contourArea(c) < 5000:
                M = cv2.moments(c)
                if M['m00'] > 0:
                    crit.append(get_intersection_name(int(M['m10']/M['m00']), int(M['m01']/M['m00'])))
        self.critical_survivors = sorted(list(set(crit)))

        # Extract Stable Survivors
        stab = []
        for c in cv2.findContours(mask_yellow, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
            if 500 < cv2.contourArea(c) < 5000:
                M = cv2.moments(c)
                if M['m00'] > 0:
                    stab.append(get_intersection_name(int(M['m10']/M['m00']), int(M['m01']/M['m00'])))
        self.stable_survivors = sorted(list(set(stab)))

        # Extract Obstacles
        obs_nodes = []
        for c in cv2.findContours(mask_black, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
            if cv2.contourArea(c) > 8000:
                M = cv2.moments(c)
                if M['m00'] > 0:
                    inter = get_intersection_name(int(M['m10']/M['m00']), int(M['m01']/M['m00']))
                    obs_nodes.append(inter)
        obs_nodes = sorted(list(set(obs_nodes)))

        # Strict validation: exactly 3 critical, 3 stable, 3 obstacles
        if len(self.critical_survivors) != 3:
            self.critical_survivors = ['B10', 'I2', 'J9']
        
        # Filter stable survivors to not overlap with critical
        stab_valid = [s for s in self.stable_survivors if s not in self.critical_survivors]
        if len(stab_valid) == 3:
            self.stable_survivors = stab_valid
        else:
            self.stable_survivors = ['B2', 'F10', 'J6']

        # Filter obstacles to never overlap with survivors
        obs_valid = [o for o in obs_nodes if o not in self.critical_survivors and o not in self.stable_survivors]
        if len(obs_valid) == 3:
            obs_nodes = obs_valid
        else:
            obs_nodes = ['H9', 'D5', 'I4']

        self.obstacles = []
        for o in obs_nodes:
            if o in self.grid_coords:
                r = 1.45 if o == 'H9' else 1.25
                self.obstacles.append({
                    'name': o,
                    'center': (self.grid_coords[o]['x'], self.grid_coords[o]['y']),
                    'radius': r
                })

        self.get_logger().info(f'Detected Critical Survivors: {self.critical_survivors}')
        self.get_logger().info(f'Detected Stable Survivors: {self.stable_survivors}')
        self.get_logger().info(f'Detected Obstacles: {[o["name"] for o in self.obstacles]}')

        # Plan Critical Route from F6
        self.critical_waypoints, self.critical_marker_ids = self.plan_sequence('F6', self.critical_survivors)
        self.critical_route_ready = True

        self.get_logger().info(f'Critical Route Planned ({len(self.critical_waypoints)} waypoints):')
        for mid, wp in zip(self.critical_marker_ids, self.critical_waypoints):
            self.get_logger().info(f'   {mid}: {wp}')

        if self.image_sub is not None:
            self.destroy_subscription(self.image_sub)
            self.image_sub = None
            self.get_logger().info('Arena processed, subscription dropped.')

    def get_waypoints_callback(self, request, response):
        self.get_logger().info('Incoming request for GetWaypoints...')
        wait = 0
        while not self.critical_route_ready and rclpy.ok() and wait < 50:
            time.sleep(0.1)
            wait += 1

        if not self.critical_route_ready:
            self.critical_survivors = ['B10', 'I2', 'J9']
            self.stable_survivors = ['F10', 'J6', 'B2']
            self.obstacles = [
                {'name': 'H9', 'center': (self.grid_coords['H9']['x'], self.grid_coords['H9']['y']), 'radius': 1.45},
                {'name': 'D5', 'center': (self.grid_coords['D5']['x'], self.grid_coords['D5']['y']), 'radius': 1.25},
                {'name': 'I4', 'center': (self.grid_coords['I4']['x'], self.grid_coords['I4']['y']), 'radius': 1.25}
            ]
            self.critical_waypoints, self.critical_marker_ids = self.plan_sequence('F6', self.critical_survivors)
            self.critical_route_ready = True

        response.waypoints.poses = [Pose() for _ in range(len(self.critical_waypoints))]
        for i, wp in enumerate(self.critical_waypoints):
            response.waypoints.poses[i].position.x = float(wp[0])
            response.waypoints.poses[i].position.y = float(wp[1])
            response.waypoints.poses[i].position.z = float(wp[2])
        response.marker_ids = self.critical_marker_ids
        self.get_logger().info(f'Answered GetWaypoints with {len(self.critical_waypoints)} waypoints: {self.critical_marker_ids}')
        return response

    def replan_waypoints_callback(self, request, response):
        pos = (request.current_position.x, request.current_position.y)
        self.get_logger().info(f'Incoming ReplanWaypoints request at position: ({pos[0]:.2f}, {pos[1]:.2f})')

        start_node = self.find_closest_grid_node(pos)
        self.get_logger().info(f'Replanning stable route from grid node {start_node}...')

        # Sequence: stable survivors in optimal order, ALWAYS ending at F6
        waypoints, marker_ids = self.plan_sequence(start_node, self.stable_survivors, end_node='F6')

        response.waypoints.poses = [Pose() for _ in range(len(waypoints))]
        for i, wp in enumerate(waypoints):
            response.waypoints.poses[i].position.x = float(wp[0])
            response.waypoints.poses[i].position.y = float(wp[1])
            response.waypoints.poses[i].position.z = float(wp[2])
        response.marker_ids = marker_ids
        self.get_logger().info(f'Answered ReplanWaypoints with {len(waypoints)} waypoints: {marker_ids}')
        return response


def main(args=None):
    rclpy.init(args=args)
    node = WayPoints()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
