#!/usr/bin/env python3

import time
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from geometry_msgs.msg import Pose, Point
from waypoint_navigation.action import NavToWaypoint
from waypoint_navigation.srv import GetWaypoints, ReplanWaypoints


class WayPointClient(Node):

    def __init__(self):
        super().__init__('waypoint_client')

        self.critical_goals = []
        self.critical_marker_ids = []
        self.stable_goals = []
        self.stable_marker_ids = []

        self.phase = 'INIT'  # 'INIT', 'CRITICAL', 'SWITCHING', 'STABLE', 'COMPLETED'
        self.current_goal_handle = None
        self.current_goal_index = 0
        self.critical_saves_count = 0
        self.switch_triggered = False

        self.takeoff_time = None
        self.last_drone_pos = [0.0068, 0.0068, 15.0]

        # Action client for 'NavToWaypoint'
        self.action_client = ActionClient(self, NavToWaypoint, 'waypoint_navigation')

        # Service client for 'GetWaypoints'
        self.get_cli = self.create_client(GetWaypoints, 'waypoints')

        # Service client for 'ReplanWaypoints'
        self.replan_cli = self.create_client(ReplanWaypoints, 'replan_waypoints')

        # Wait for GetWaypoints service
        while not self.get_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('GetWaypoints service not available, waiting...')

        # Request critical route
        self.receive_critical_goals()

        # Timer for 55s critical window monitoring (10 Hz)
        self.monitor_timer = self.create_timer(0.1, self.check_critical_timeout)

    def receive_critical_goals(self):
        self.get_logger().info('Requesting critical route from GetWaypoints...')
        req = GetWaypoints.Request()
        req.get_waypoints = True
        future = self.get_cli.call_async(req)
        future.add_done_callback(self.get_waypoints_response_callback)

    def get_waypoints_response_callback(self, future):
        try:
            response = future.result()
            self.critical_goals = []
            self.critical_marker_ids = list(response.marker_ids)
            for pose in response.waypoints.poses:
                self.critical_goals.append([pose.position.x, pose.position.y, pose.position.z])

            self.get_logger().info(f'Received {len(self.critical_goals)} critical waypoints: {self.critical_marker_ids}')

            # Wait for action server and start critical route
            self.get_logger().info('Waiting for Action Server (waypoint_navigation)...')
            self.action_client.wait_for_server()
            self.get_logger().info('Action Server ready! Commencing mission...')

            self.phase = 'CRITICAL'
            self.current_goal_index = 0
            self.send_next_critical_goal()

        except Exception as e:
            self.get_logger().error(f'Failed to get waypoints: {e}')

    def send_next_critical_goal(self):
        if self.current_goal_index >= len(self.critical_goals):
            self.get_logger().info('All critical waypoints dispatched. Triggering THE SWITCH...')
            self.trigger_switch()
            return

        wp = self.critical_goals[self.current_goal_index]
        mid = self.critical_marker_ids[self.current_goal_index]
        hover = not (mid.startswith('TRANSIT') or mid.startswith('DETOUR'))

        self.get_logger().info(f'Sending Critical Goal {self.current_goal_index + 1}/{len(self.critical_goals)}: {mid} -> {wp} (hover={hover})')
        self.send_goal(wp, hover)

    def send_goal(self, waypoint, hover=True):
        goal_msg = NavToWaypoint.Goal()
        goal_msg.waypoint.position.x = float(waypoint[0])
        goal_msg.waypoint.position.y = float(waypoint[1])
        goal_msg.waypoint.position.z = float(waypoint[2])
        goal_msg.hover = hover

        send_future = self.action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
        send_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn('Goal rejected by action server!')
            return

        self.current_goal_handle = goal_handle
        self.get_logger().info('Goal accepted by action server.')

        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        self.current_goal_handle = None
        result = future.result().result
        self.get_logger().info(f'Goal finished with hold result: {result.hov_time}s')

        if self.phase == 'CRITICAL':
            mid = self.critical_marker_ids[self.current_goal_index]
            if not (mid.startswith('TRANSIT') or mid.startswith('DETOUR')):
                self.critical_saves_count += 1
                self.get_logger().info(f'Critical Survivor {mid} SAVE complete ({self.critical_saves_count}/3)!')

            self.current_goal_index += 1

            if self.critical_saves_count >= 3 or self.current_goal_index >= len(self.critical_goals):
                self.get_logger().info('Critical phase complete! Triggering THE SWITCH...')
                self.trigger_switch()
            elif not self.switch_triggered:
                self.send_next_critical_goal()

        elif self.phase == 'STABLE':
            self.current_goal_index += 1
            if self.current_goal_index < len(self.stable_goals):
                self.send_next_stable_goal()
            else:
                self.phase = 'COMPLETED'
                self.get_logger().info('ALL 6 SURVIVORS SAVED AND LANDED ON F6! MISSION ACCOMPLISHED.')
                time.sleep(1.0)
                rclpy.shutdown()

    def feedback_callback(self, feedback_msg):
        fb = feedback_msg.feedback
        px = fb.current_waypoint.pose.position.x
        py = fb.current_waypoint.pose.position.y
        pz = fb.current_waypoint.pose.position.z
        t_in = fb.current_waypoint.header.stamp.sec
        self.last_drone_pos = [px, py, pz]

        if self.takeoff_time is None and pz <= 14.7:
            self.takeoff_time = time.time()
            self.get_logger().info(f'LIFT-OFF DETECTED (Z = {pz:.2f})! Starting 55s critical timer.')

        if self.takeoff_time is not None:
            elapsed = time.time() - self.takeoff_time
            if int(elapsed) % 10 == 0 and int(elapsed) > 0:
                self.get_logger().info(f'Flight Time: {elapsed:.1f}s / 55s (Phase: {self.phase}) | Pos: ({px:.2f}, {py:.2f}, {pz:.2f})')

    def check_critical_timeout(self):
        if self.phase != 'CRITICAL' or self.switch_triggered:
            return

        if self.takeoff_time is not None:
            elapsed = time.time() - self.takeoff_time
            if elapsed >= 55.0:
                self.get_logger().warn(f'Critical Window Expired (elapsed: {elapsed:.2f}s >= 55s)! Triggering THE SWITCH...')
                self.trigger_switch()

    def trigger_switch(self):
        if self.switch_triggered:
            return
        self.switch_triggered = True
        self.phase = 'SWITCHING'
        self.get_logger().info('=== TRIGGERING THE SWITCH ===')

        if self.current_goal_handle is not None:
            self.get_logger().info('Cancelling active critical goal...')
            cancel_future = self.current_goal_handle.cancel_goal_async()
            cancel_future.add_done_callback(self.on_goal_canceled)
        else:
            self.call_replan_service()

    def on_goal_canceled(self, future):
        self.get_logger().info('Active goal successfully cancelled. Calling ReplanWaypoints...')
        self.current_goal_handle = None
        self.call_replan_service()

    def call_replan_service(self):
        while not self.replan_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('ReplanWaypoints service not available, waiting...')

        req = ReplanWaypoints.Request()
        req.current_position.x = float(self.last_drone_pos[0])
        req.current_position.y = float(self.last_drone_pos[1])
        req.current_position.z = float(self.last_drone_pos[2])

        self.get_logger().info(f'Requesting stable route from position: ({req.current_position.x:.2f}, {req.current_position.y:.2f})...')
        replan_future = self.replan_cli.call_async(req)
        replan_future.add_done_callback(self.replan_response_callback)

    def replan_response_callback(self, future):
        try:
            response = future.result()
            self.stable_goals = []
            self.stable_marker_ids = list(response.marker_ids)
            for pose in response.waypoints.poses:
                self.stable_goals.append([pose.position.x, pose.position.y, pose.position.z])

            self.get_logger().info(f'Received Stable Route ({len(self.stable_goals)} waypoints): {self.stable_marker_ids}')

            self.phase = 'STABLE'
            self.current_goal_index = 0
            self.send_next_stable_goal()

        except Exception as e:
            self.get_logger().error(f'Failed to get replanned waypoints: {e}')

    def send_next_stable_goal(self):
        if self.current_goal_index >= len(self.stable_goals):
            self.phase = 'COMPLETED'
            self.get_logger().info('All stable goals finished!')
            return

        wp = self.stable_goals[self.current_goal_index]
        mid = self.stable_marker_ids[self.current_goal_index]
        hover = not (mid.startswith('TRANSIT') or mid.startswith('DETOUR'))

        self.get_logger().info(f'Sending Stable Goal {self.current_goal_index + 1}/{len(self.stable_goals)}: {mid} -> {wp} (hover={hover})')
        self.send_goal(wp, hover)


def main(args=None):
    rclpy.init(args=args)
    client = WayPointClient()
    try:
        rclpy.spin(client)
    except Exception:
        pass
    finally:
        try:
            client.destroy_node()
        except Exception:
            pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
