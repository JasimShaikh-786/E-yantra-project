#!/usr/bin/env python3

import time
import math
try:
    from tf_transformations import euler_from_quaternion
except ImportError:
    def euler_from_quaternion(quaternion):
        x, y, z, w = quaternion
        sinr_cosp = 2.0 * (w * x + y * z)
        cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        sinp = 2.0 * (w * y - z * x)
        if abs(sinp) >= 1.0:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        return roll, pitch, yaw

import rclpy
from rclpy.action import ActionServer, CancelResponse
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

# Pico control specific libraries
from swift_msgs.msg import SwiftMsgs
from std_msgs.msg import Header
from whycode_interfaces.msg import MarkerArray
from error_msg.msg import Error
from controller_msg.msg import PIDTune
from nav_msgs.msg import Odometry

# Action interface
from waypoint_navigation.action import NavToWaypoint


class WayPointServer(Node):

    def __init__(self):
        super().__init__('waypoint_server')

        self.pid_callback_group = ReentrantCallbackGroup()
        self.action_callback_group = ReentrantCallbackGroup()
        self.sub_callback_group = ReentrantCallbackGroup()

        self.yaw = 0.0              # current yaw in degrees (updated from whycode)
        self.desired_yaw = -0.5     # target yaw angle (degrees)
        self.prev_yaw_error = 0.0

        self.curr_state = [0.0068, 0.0068, 15.0]     # drone starts on ground at z ~ 15.0
        self.desired_state = [0.0068, 0.0068, 15.0]  # initial ground state before first goal arrives
        self.drone_position = [0.0, 0.0, 15.0]
        self.dtime = 0.0
        self._got_position = False
        self.in_flight = False

        # Drone command message
        self.cmd = SwiftMsgs()
        self.cmd.rc_roll = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4 = 1500

        self.target_state = [0.0068, 0.0068, 15.0]
        self.ramp_speed_xy = 2.4  # m/s
        self.ramp_speed_z = 2.0   # m/s
        self.prev_pos = [0.0068, 0.0068, 15.0]

        # Tuned PID gains with Derivative-on-Measurement velocity damping
        self.Kp = [22.0, 22.0, 45.0]
        self.Ki = [0.01, 0.01, 0.05]
        self.Kd = [1800.0, 1800.0, 1500.0]

        self.prev_error = [0.0, 0.0, 0.0]
        self.error_sum = [0.0, 0.0, 0.0]

        self.max_values = [2000, 2000, 2000]
        self.min_values = [1000, 1000, 1000]

        self.pos_error = Error()
        self.sample_time = 0.033  # ~30 Hz, matching WhyCode rate

        # Publishers
        self.command_pub = self.create_publisher(SwiftMsgs, '/drone_command', 10)
        self.pos_error_pub = self.create_publisher(Error, '/pos_error', 10)
        self.heartbeat_pub = self.create_publisher(Header, '/controller_heartbeat', 10)

        # Subscribers
        self.create_subscription(
            MarkerArray,
            '/whycode_node/markers',
            self.whycode_callback,
            1,
            callback_group=self.sub_callback_group
        )

        self.create_subscription(
            Odometry,
            '/rotors/odometry',
            self.odometry_callback,
            10,
            callback_group=self.sub_callback_group
        )

        # Action server with cancel support
        self._action_server = ActionServer(
            self,
            NavToWaypoint,
            'waypoint_navigation',
            execute_callback=self.execute_callback,
            cancel_callback=self.cancel_callback,
            callback_group=self.action_callback_group
        )

        # Heartbeat timer (10 Hz)
        self.publish_heartbeat()
        self.create_timer(0.1, self.publish_heartbeat, callback_group=self.pid_callback_group)

        time.sleep(0.5)  # Let heartbeat reach rosbag before arming
        self.arm()

        # PID control loop timer
        self.timer = self.create_timer(
            self.sample_time,
            self.pid,
            callback_group=self.pid_callback_group
        )
        self.get_logger().info('Task 3A Waypoint Action Server initialized and armed.')

    def publish_heartbeat(self):
        hb = Header()
        hb.stamp = self.get_clock().now().to_msg()
        hb.frame_id = 'pico_controller_active'
        self.heartbeat_pub.publish(hb)

    def disarm(self):
        self.cmd.rc_roll = 1000
        self.cmd.rc_yaw = 1000
        self.cmd.rc_pitch = 1000
        self.cmd.rc_throttle = 1000
        self.cmd.rc_aux4 = 1000
        self.command_pub.publish(self.cmd)
        self.get_logger().info('Drone DISARMED.')

    def arm(self):
        self.disarm()
        self.cmd.rc_roll = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4 = 2000
        self.command_pub.publish(self.cmd)
        self.get_logger().info('Drone ARMED.')

    def whycode_callback(self, msg):
        if not msg.markers:
            return

        marker = msg.markers[0]
        pos = marker.position.position
        self.curr_state = [pos.x, pos.y, pos.z]
        self.drone_position = self.curr_state[:]
        self.yaw = math.degrees(marker.rotation.z)
        self.dtime = float(msg.header.stamp.sec) + float(msg.header.stamp.nanosec) * 1e-9
        self._got_position = True

    def odometry_callback(self, msg):
        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        roll, pitch, yaw = euler_from_quaternion(orientation_list)
        self.roll_deg = math.degrees(roll)
        self.pitch_deg = math.degrees(pitch)
        self.yaw_deg = math.degrees(yaw)

    def pid(self):
        if not self._got_position:
            return

        if not self.in_flight:
            self.cmd.rc_roll = 1500
            self.cmd.rc_pitch = 1500
            self.cmd.rc_yaw = 1500
            self.cmd.rc_throttle = 1000
            self.cmd.rc_aux4 = 2000
            self.command_pub.publish(self.cmd)
            return

        self.desired_state = list(self.target_state)

        # Coordinate conventions:
        # X: Pitch (forward/back)
        # Y: Roll  (left/right)
        # Z: Altitude/throttle (ground ~ 15.0, fly ~ 13.0)
        pitch_err    = self.desired_state[0] - self.curr_state[0]
        roll_err     = self.desired_state[1] - self.curr_state[1]
        throttle_err = self.curr_state[2] - self.desired_state[2]

        errors = [roll_err, pitch_err, throttle_err]

        # Position change (velocity * dt)
        d_pos_y = self.curr_state[1] - self.prev_pos[1]  # roll direction
        d_pos_x = self.curr_state[0] - self.prev_pos[0]  # pitch direction
        d_pos_z = self.curr_state[2] - self.prev_pos[2]  # altitude direction
        self.prev_pos = self.curr_state[:]

        # Integral with anti-windup clamping
        for i in range(3):
            self.error_sum[i] += errors[i]
            self.error_sum[i] = max(-300.0, min(300.0, self.error_sum[i]))

        # PID outputs (Derivative-on-Measurement directly damps velocity without derivative kick)
        out_roll     = self.Kp[0] * roll_err     + self.Ki[0] * self.error_sum[0] - self.Kd[0] * d_pos_y
        out_pitch    = self.Kp[1] * pitch_err    + self.Ki[1] * self.error_sum[1] - self.Kd[1] * d_pos_x
        out_throttle = self.Kp[2] * throttle_err + self.Ki[2] * self.error_sum[2] + self.Kd[2] * d_pos_z

        # Clamp tilt output to safe, agile +/- 180 PWM (~25 deg tilt)
        out_roll  = max(-180.0, min(180.0, out_roll))
        out_pitch = max(-180.0, min(180.0, out_pitch))
        out_throttle = max(-200.0, min(200.0, out_throttle))

        self.cmd.rc_roll     = int(1500 + out_roll)
        self.cmd.rc_pitch    = int(1500 + out_pitch)
        self.cmd.rc_throttle = int(1500 + out_throttle)
        self.cmd.rc_aux4     = 2000

        # Yaw PD control to maintain desired_yaw
        yaw_err = self.desired_yaw - self.yaw
        yaw_err = (yaw_err + 180.0) % 360.0 - 180.0
        d_yaw_err = yaw_err - self.prev_yaw_error
        out_yaw = 6.0 * yaw_err + 2.0 * d_yaw_err
        self.cmd.rc_yaw = int(1500 + out_yaw)
        self.prev_yaw_error = yaw_err

        # Clamp RC values to [1000, 2000]
        self.cmd.rc_roll     = max(self.min_values[0], min(self.max_values[0], self.cmd.rc_roll))
        self.cmd.rc_pitch    = max(self.min_values[1], min(self.max_values[1], self.cmd.rc_pitch))
        self.cmd.rc_throttle = max(self.min_values[2], min(self.max_values[2], self.cmd.rc_throttle))
        self.cmd.rc_yaw      = max(1000, min(2000, self.cmd.rc_yaw))

        self.command_pub.publish(self.cmd)

        self.pos_error.roll_error     = float(roll_err)
        self.pos_error.pitch_error    = float(pitch_err)
        self.pos_error.throttle_error = float(throttle_err)
        self.pos_error.yaw_error      = float(yaw_err)
        self.pos_error_pub.publish(self.pos_error)

        self.prev_error = errors[:]

    def is_in_sphere(self, tx, ty, tz, radius=0.4):
        # 0.4 whycode units sphere centered on hold point
        dx = self.curr_state[0] - tx
        dy = self.curr_state[1] - ty
        dz = self.curr_state[2] - tz
        return math.sqrt(dx*dx + dy*dy + dz*dz) <= radius

    def cancel_callback(self, goal_handle):
        self.get_logger().info('Received cancel request for active goal. Accepting.')
        return CancelResponse.ACCEPT

    def execute_callback(self, goal_handle):
        req = goal_handle.request
        target_x = float(req.waypoint.position.x)
        target_y = float(req.waypoint.position.y)
        hover_requested = req.hover

        # Check if target is F6 (base station)
        is_f6 = (abs(target_x - 0.0068) < 0.35 and abs(target_y - 0.0068) < 0.35)

        self.get_logger().info(f'New Goal: ({target_x:.2f}, {target_y:.2f}) hover={hover_requested} is_f6={is_f6}')
        self.in_flight = True
        start_exec_time = time.time()
        feedback_msg = NavToWaypoint.Feedback()

        # CASE 1: Transit Waypoint (hover == False) - fly past at Z = 13 without stopping
        if not hover_requested:
            self.target_state = [target_x, target_y, 13.0]
            while rclpy.ok():
                if goal_handle.is_cancel_requested:
                    self.get_logger().info('Transit goal cancelled by client.')
                    goal_handle.canceled()
                    self.target_state = [self.curr_state[0], self.curr_state[1], 13.0]
                    self.desired_state = [self.curr_state[0], self.curr_state[1], 13.0]
                    res = NavToWaypoint.Result()
                    res.hov_time = int(time.time() - start_exec_time)
                    return res

                feedback_msg.current_waypoint.pose.position.x = float(self.curr_state[0])
                feedback_msg.current_waypoint.pose.position.y = float(self.curr_state[1])
                feedback_msg.current_waypoint.pose.position.z = float(self.curr_state[2])
                feedback_msg.current_waypoint.header.stamp.sec = 0
                goal_handle.publish_feedback(feedback_msg)

                # Fly past: proceed as soon as within 0.85m of transit waypoint
                if math.hypot(self.curr_state[0] - target_x, self.curr_state[1] - target_y) <= 0.85:
                    self.get_logger().info(f'Flew past transit waypoint ({target_x:.2f}, {target_y:.2f})')
                    break
                time.sleep(0.04)

            goal_handle.succeed()
            res = NavToWaypoint.Result()
            res.hov_time = 0
            return res

        # CASE 2: Base Station F6 - Hover at Z = 13 for 1.0s, then descend and land
        if is_f6:
            self.get_logger().info('Home F6 reached. Executing Hover at Z = 13 (1s), then Landing...')
            self.target_state = [target_x, target_y, 13.0]

            # Hover at Z = 13 for 1.1s
            time_inside = 0.0
            t_enter = None
            while rclpy.ok():
                if goal_handle.is_cancel_requested:
                    goal_handle.canceled()
                    res = NavToWaypoint.Result()
                    res.hov_time = 0
                    return res

                in_sphere = self.is_in_sphere(target_x, target_y, 13.0, radius=0.4)
                cur_t = self.dtime if self.dtime > 0 else time.time()
                if in_sphere:
                    if t_enter is None:
                        t_enter = cur_t
                    time_inside = cur_t - t_enter
                else:
                    t_enter = None
                    time_inside = 0.0

                feedback_msg.current_waypoint.pose.position.x = float(self.curr_state[0])
                feedback_msg.current_waypoint.pose.position.y = float(self.curr_state[1])
                feedback_msg.current_waypoint.pose.position.z = float(self.curr_state[2])
                feedback_msg.current_waypoint.header.stamp.sec = int(time_inside)
                goal_handle.publish_feedback(feedback_msg)

                if time_inside >= 1.08:
                    self.get_logger().info('F6 Hover complete (1.08s at Z = 13.0). Descending to land...')
                    break
                time.sleep(0.04)

            # Descend to ground (Z ~ 15.0)
            self.target_state = [target_x, target_y, 15.0]
            while rclpy.ok():
                feedback_msg.current_waypoint.pose.position.x = float(self.curr_state[0])
                feedback_msg.current_waypoint.pose.position.y = float(self.curr_state[1])
                feedback_msg.current_waypoint.pose.position.z = float(self.curr_state[2])
                goal_handle.publish_feedback(feedback_msg)

                if self.curr_state[2] >= 14.85:
                    self.get_logger().info('Drone settled on ground. Disarming...')
                    break
                time.sleep(0.04)

            time.sleep(0.3)
            self.disarm()
            goal_handle.succeed()
            res = NavToWaypoint.Result()
            res.hov_time = 1
            return res

        # CASE 3: Survivor Saving Maneuver (Visit: 1s at Z = 13; Save: 2s at Z = 14)
        # Step 3.1: Visit (Z = 13.0, 1.1s continuous)
        self.target_state = [target_x, target_y, 13.0]
        time_inside = 0.0
        t_enter = None
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self.get_logger().info('Goal cancel requested during Visit.')
                goal_handle.canceled()
                self.target_state = [self.curr_state[0], self.curr_state[1], 13.0]
                self.desired_state = [self.curr_state[0], self.curr_state[1], 13.0]
                res = NavToWaypoint.Result()
                res.hov_time = int(time_inside)
                return res

            in_sphere = self.is_in_sphere(target_x, target_y, 13.0, radius=0.4)
            cur_t = self.dtime if self.dtime > 0 else time.time()
            if in_sphere:
                if t_enter is None:
                    t_enter = cur_t
                time_inside = cur_t - t_enter
            else:
                t_enter = None
                time_inside = 0.0

            feedback_msg.current_waypoint.pose.position.x = float(self.curr_state[0])
            feedback_msg.current_waypoint.pose.position.y = float(self.curr_state[1])
            feedback_msg.current_waypoint.pose.position.z = float(self.curr_state[2])
            feedback_msg.current_waypoint.header.stamp.sec = int(time_inside)
            goal_handle.publish_feedback(feedback_msg)

            if time_inside >= 1.08:
                self.get_logger().info(f'VISIT complete for ({target_x:.2f}, {target_y:.2f}) at Z = 13 (1.08s). Proceeding to SAVE...')
                break
            time.sleep(0.04)

        # Step 3.2: Save (Z = 14.0, 2.08 continuous seconds)
        self.target_state = [target_x, target_y, 14.0]
        time_inside = 0.0
        t_enter = None
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self.get_logger().info('Goal cancel requested during Save.')
                goal_handle.canceled()
                self.target_state = [self.curr_state[0], self.curr_state[1], 13.0]
                self.desired_state = [self.curr_state[0], self.curr_state[1], 13.0]
                res = NavToWaypoint.Result()
                res.hov_time = int(time_inside)
                return res

            in_sphere = self.is_in_sphere(target_x, target_y, 14.0, radius=0.4)
            cur_t = self.dtime if self.dtime > 0 else time.time()
            if in_sphere:
                if t_enter is None:
                    t_enter = cur_t
                time_inside = cur_t - t_enter
            else:
                t_enter = None
                time_inside = 0.0

            feedback_msg.current_waypoint.pose.position.x = float(self.curr_state[0])
            feedback_msg.current_waypoint.pose.position.y = float(self.curr_state[1])
            feedback_msg.current_waypoint.pose.position.z = float(self.curr_state[2])
            feedback_msg.current_waypoint.header.stamp.sec = int(time_inside)
            goal_handle.publish_feedback(feedback_msg)

            if time_inside >= 2.08:
                self.get_logger().info(f'SAVE complete for ({target_x:.2f}, {target_y:.2f}) at Z = 14 (2.08s)!')
                break
            time.sleep(0.04)

        goal_handle.succeed()
        res = NavToWaypoint.Result()
        res.hov_time = 3
        return res


def main(args=None):
    rclpy.init(args=args)
    waypoint_server = WayPointServer()
    executor = MultiThreadedExecutor()
    executor.add_node(waypoint_server)
    try:
        executor.spin()
    except KeyboardInterrupt:
        waypoint_server.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        waypoint_server.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
